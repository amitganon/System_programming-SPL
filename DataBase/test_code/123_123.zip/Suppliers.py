from DAO_Object import DAO_Object


class Suppliers (DAO_Object):

    def __init__(self, supplier, con):
        super().__init__(supplier, con)
