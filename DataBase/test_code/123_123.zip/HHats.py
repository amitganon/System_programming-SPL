from DAO_Object import DAO_Object


class Hats (DAO_Object):

    def __init__(self, hat, con):
        super().__init__(hat, con)