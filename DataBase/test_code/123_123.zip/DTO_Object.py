class DTO_Object:

    def __init__(self, id):
        self.id = id
