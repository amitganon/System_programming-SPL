from DAO_Object import DAO_Object


class Orders (DAO_Object):

    def __init__(self, order, con):
        super().__init__(order, con)
